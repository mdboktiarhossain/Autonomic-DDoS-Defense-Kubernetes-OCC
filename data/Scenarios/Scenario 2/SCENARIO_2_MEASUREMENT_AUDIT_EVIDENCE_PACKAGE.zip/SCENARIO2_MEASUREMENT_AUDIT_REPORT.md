# Scenario 2: Comprehensive 5-Point Measurement Audit & Methodology Validation

**Date:** November 7, 2026  
**Cluster:** Minikube v1.33+ (12 vCPUs, 16 GiB RAM, Linux kernel 5.15) on Ubuntu VM `192.168.160.129`  
**Evaluated Systems:**
- **Architecture A (Decentralized):** 4 $\times$ 1-core Pods (`ddos-defender-product`, `details`, `reviews`, `ratings`), 6-worker `ThreadPoolExecutor`, total 4.0 CPU cores.
- **Architecture B (Centralized Sequential Baseline):** 1 $\times$ 4-core Pod (`scenario2-central-b`), centralized sequential controller with global lock, total 4.0 CPU cores.
- **Workload:** Certified `test4_workload_1000.json` (SHA-256: `2bb111d75e97a91c74f0881a5cd3e0fdc5e103129479cb666fa60ffb8f7e7e0f`).

---

## 1. Executive Summary of Audit Findings

The measurement audit confirms that:
1. **The performance divergence is driven by server-side architectural serialization, not client-side artifacts.**
2. Increasing the benchmark client-side worker count from $32$ to $64$ produced an identical centralized throughput ceiling ($41.64\text{ req/s}$ vs. $41.66\text{ req/s}$), proving the bottleneck is strictly the server's serial inference lock ($T_{\mathrm{service}} \approx 23.5\text{ ms} \implies Q_{\max} \approx 42.5\text{ req/s}$).
3. When offered load exceeds $42.5\text{ req/s}$, Architecture B accumulates both server-side lock wait queues ($T_{\mathrm{server}} \approx 650\text{--}724\text{ ms}$) and client-side scheduling queues ($L_{\mathrm{client\ queue}} \approx 761\text{--}2487\text{ ms}$), driving end-to-end latency ($L_{\mathrm{sub}}$) past $1.4\text{ to }3.2\text{ seconds}$.
4. Architecture A (Decentralized) scales effortlessly across all tested loads ($30\text{ to }120\text{ RPS}$):
   - $L_{\mathrm{client\ queue}} \le 0.23\text{ ms}$ (client queue is essentially empty).
   - $T_{\mathrm{server}} \le 6.1\text{ ms}$ across all loads.
   - Mean end-to-end latency remains $\le 9.56\text{ ms}$ even at $120\text{ RPS}$ ($+190.2\%$ higher throughput than centralized).
5. Exact prediction parity is $100\%$ ($0$ mismatches across all $4,800$ audited evaluation requests).

---

## 2. Five-Point Latency Decomposition Audit

### Latency Definitions
$$\begin{aligned}
T_{\mathrm{model}} &= \text{Pure model computation time inside the container process} \\
T_{\mathrm{server}} &= \text{FastAPI/uvicorn endpoint duration (lock acquisition + inference + serialization)} \\
L_{\mathrm{HTTP}} &= \text{Client observed roundtrip time } (t_{\mathrm{response}} - t_{\mathrm{request\ start}}) \\
L_{\mathrm{client\ queue}} &= \text{Time request spent queued in client pool waiting for a worker thread} \\
L_{\mathrm{sub}} &= \text{Total submission-to-completion delay } (L_{\mathrm{client\ queue}} + L_{\mathrm{HTTP}})
\end{aligned}$$

---

### Condition 1: Load Sweep Without Background Flood (Empirical Averages)

| Load | Metric | Architecture A (Decentralized) | Architecture B (Centralized Seq.) | Delta / Gain |
| :--- | :--- | :---: | :---: | :---: |
| **30 RPS** | $Q_{\mathrm{meas}}$ (Throughput) | **$29.93\text{ req/s}$** | **$30.02\text{ req/s}$** | Parity (Load satisfied) |
| | $T_{\mathrm{model}}$ (mean) | $4.12\text{ ms}$ | $22.35\text{ ms}$ | $-81.6\%$ |
| | $T_{\mathrm{server}}$ (mean) | $5.07\text{ ms}$ | $29.82\text{ ms}$ | $-83.0\%$ |
| | $L_{\mathrm{HTTP}}$ (mean / p95) | $8.06\text{ ms}$ / $21.99\text{ ms}$ | $32.29\text{ ms}$ / $80.04\text{ ms}$ | **$-75.0\%$** |
| | $L_{\mathrm{client\ queue}}$ (mean) | $0.22\text{ ms}$ | $0.21\text{ ms}$ | Negligible ($\sim 0.2\text{ ms}$) |
| | $L_{\mathrm{sub}}$ (mean / p95) | **$8.28\text{ ms}$** / $22.11\text{ ms}$ | **$32.50\text{ ms}$** / $80.19\text{ ms}$ | **$-74.5\%$** |
| **60 RPS** | $Q_{\mathrm{meas}}$ (Throughput) | **$60.10\text{ req/s}$** | **$43.39\text{ req/s}$** | **$+38.5\%$ throughput gain** |
| | $T_{\mathrm{model}}$ (mean) | $3.77\text{ ms}$ | $22.80\text{ ms}$ | $-83.5\%$ |
| | $T_{\mathrm{server}}$ (mean) | $4.53\text{ ms}$ | $650.31\text{ ms}$ | Lock queue backlog in B |
| | $L_{\mathrm{HTTP}}$ (mean / p95) | $6.86\text{ ms}$ / $11.55\text{ ms}$ | $653.44\text{ ms}$ / $882.06\text{ ms}$ | **$-99.0\%$** |
| | $L_{\mathrm{client\ queue}}$ (mean) | $0.19\text{ ms}$ | $761.73\text{ ms}$ | Client pool queues for B |
| | $L_{\mathrm{sub}}$ (mean / p95) | **$7.04\text{ ms}$** / $11.74\text{ ms}$ | **$1415.17\text{ ms}$** / $2684.85\text{ ms}$ | **$-99.5\%$** |
| **90 RPS** | $Q_{\mathrm{meas}}$ (Throughput) | **$90.12\text{ req/s}$** | **$43.17\text{ req/s}$** | **$+108.8\%$ throughput gain** |
| | $T_{\mathrm{model}}$ (mean) | $3.87\text{ ms}$ | $22.99\text{ ms}$ | $-83.2\%$ |
| | $T_{\mathrm{server}}$ (mean) | $4.62\text{ ms}$ | $679.85\text{ ms}$ | Severe lock wait in B |
| | $L_{\mathrm{HTTP}}$ (mean / p95) | $7.24\text{ ms}$ / $11.59\text{ ms}$ | $682.04\text{ ms}$ / $950.30\text{ ms}$ | **$-98.9\%$** |
| | $L_{\mathrm{client\ queue}}$ (mean) | $0.18\text{ ms}$ | $1693.21\text{ ms}$ | Deep client queue for B |
| | $L_{\mathrm{sub}}$ (mean / p95) | **$7.42\text{ ms}$** / $11.75\text{ ms}$ | **$2375.25\text{ ms}$** / $4675.44\text{ ms}$ | **$-99.7\%$** |
| **120 RPS** | $Q_{\mathrm{meas}}$ (Throughput) | **$120.13\text{ req/s}$** | **$41.40\text{ req/s}$** | **$+190.2\%$ throughput gain** |
| | $T_{\mathrm{model}}$ (mean) | $4.89\text{ ms}$ | $23.90\text{ ms}$ | $-79.5\%$ |
| | $T_{\mathrm{server}}$ (mean) | $6.09\text{ ms}$ | $724.12\text{ ms}$ | Max lock queue in B |
| | $L_{\mathrm{HTTP}}$ (mean / p95) | $9.38\text{ ms}$ / $20.02\text{ ms}$ | $726.94\text{ ms}$ / $960.51\text{ ms}$ | **$-98.7\%$** |
| | $L_{\mathrm{client\ queue}}$ (mean) | $0.18\text{ ms}$ | $2487.35\text{ ms}$ | Saturation runaway for B |
| | $L_{\mathrm{sub}}$ (mean / p95) | **$9.56\text{ ms}$** / $20.12\text{ ms}$ | **$3214.29\text{ ms}$** / $5991.24\text{ ms}$ | **$-99.7\%$** |

---

### Condition 2: During Synchronized 4-Service Background Traffic

| Load | Metric | Architecture A (Decentralized) | Architecture B (Centralized Seq.) | Delta / Gain |
| :--- | :--- | :---: | :---: | :---: |
| **60 RPS** | $Q_{\mathrm{meas}}$ (Throughput) | **$60.09\text{ req/s}$** | **$41.66\text{ req/s}$** | **$+44.2\%$ throughput gain** |
| | $T_{\mathrm{model}}$ (mean / p95) | $3.73\text{ ms}$ / $7.70\text{ ms}$ | $23.76\text{ ms}$ / $38.65\text{ ms}$ | $-84.3\%$ |
| | $T_{\mathrm{server}}$ (mean / p95) | $4.44\text{ ms}$ / $8.59\text{ ms}$ | $677.93\text{ ms}$ / $922.82\text{ ms}$ | Lock contention in B |
| | $L_{\mathrm{HTTP}}$ (mean / p95) | $6.71\text{ ms}$ / $11.43\text{ ms}$ | $680.72\text{ ms}$ / $926.66\text{ ms}$ | **$-99.0\%$** |
| | $L_{\mathrm{client\ queue}}$ (mean / p95) | $0.21\text{ ms}$ / $0.51\text{ ms}$ | $865.49\text{ ms}$ / $2137.59\text{ ms}$ | Open-loop queueing in B |
| | $L_{\mathrm{sub}}$ (mean / p95) | **$6.92\text{ ms}$** / $11.69\text{ ms}$ | **$1546.21\text{ ms}$** / $2868.44\text{ ms}$ | **$-99.6\%$** |
| **90 RPS** | $Q_{\mathrm{meas}}$ (Throughput) | **$90.12\text{ req/s}$** | **$42.22\text{ req/s}$** | **$+113.5\%$ throughput gain** |
| | $T_{\mathrm{model}}$ (mean / p95) | $4.24\text{ ms}$ / $8.94\text{ ms}$ | $23.38\text{ ms}$ / $39.08\text{ ms}$ | $-81.9\%$ |
| | $T_{\mathrm{server}}$ (mean / p95) | $5.44\text{ ms}$ / $10.57\text{ ms}$ | $699.24\text{ ms}$ / $917.63\text{ ms}$ | Heavy serialization in B |
| | $L_{\mathrm{HTTP}}$ (mean / p95) | $8.93\text{ ms}$ / $15.80\text{ ms}$ | $701.72\text{ ms}$ / $920.73\text{ ms}$ | **$-98.7\%$** |
| | $L_{\mathrm{client\ queue}}$ (mean / p95) | $0.23\text{ ms}$ / $0.70\text{ ms}$ | $1880.75\text{ ms}$ / $3941.61\text{ ms}$ | High queue wait in B |
| | $L_{\mathrm{sub}}$ (mean / p95) | **$9.16\text{ ms}$** / $16.09\text{ ms}$ | **$2582.46\text{ ms}$** / $4692.19\text{ ms}$ | **$-99.6\%$** |

---

## 3. Client-Worker Sensitivity Audit: 32 vs 64 Workers

To verify whether the client thread pool (`client_workers=32`) artificially throttled Architecture B, an empirical test was conducted at $60\text{ RPS}$ with $64\text{ workers}$:

| Client Workers | Metric | Arm A (Decentralized) | Arm B (Centralized Sequential) | Observation |
| :---: | :---: | :---: | :---: | :--- |
| **32 Workers** | Measured Throughput | $60.09\text{ req/s}$ | **$41.66\text{ req/s}$** | Saturation ceiling observed |
| **64 Workers** | Measured Throughput | $60.15\text{ req/s}$ | **$41.64\text{ req/s}$** | **Identical throughput ceiling ($\Delta < 0.05\%$)** |

> [!IMPORTANT]
> **Server-Side Bottleneck Established:**
> Doubling the client concurrency pool from $32$ to $64$ workers produces virtually identical centralized throughput ($41.64\text{ req/s}$). This proves conclusively that the bottleneck is the centralized server's serial inference critical section ($T_{\mathrm{service}} \approx 23.5\text{ ms}$), not client pool starvation.

---

## 4. Reconciled Request Counts & Parity

Across all audited pilot and sweep runs:
- **Total Requests Evaluated:** $4,800$ requests.
- **HTTP Failures / Timeouts:** $0$ ($100\%$ success rate).
- **Prediction Mismatches ($A \neq B$):** **$0$** ($100\%$ bit-exact classification parity between decentralized and centralized arms).
- **Security Check:** All evaluation requests strictly passed SHA-256 workload validation and bearer token authentication.

---

## 5. Next Step: Execution of Final 10 Paired Repetitions

With the 5 audit requirements satisfied and verified, the benchmark harness is validated to run the definitive **10 paired repetitions** under Condition 2 (synchronized four-service attack at $60\text{ RPS}$ and $90\text{ RPS}$) to compute final publication confidence intervals.

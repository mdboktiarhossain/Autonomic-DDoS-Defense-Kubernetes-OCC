import os, paramiko, glob

ssh_pass = os.getenv('VM_SSH_PASSWORD') or os.getenv('SSH_PASS')
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('192.168.160.129', username='osu', password=ssh_pass, timeout=15)

def run(cmd):
    stdin, stdout, stderr = c.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='ignore').strip()
    err = stderr.read().decode('utf-8', errors='ignore').strip()
    return out, err

print("Preparing /tmp/paper_build on VM...")
run("rm -rf /tmp/paper_build && mkdir -p /tmp/paper_build/figures")

sftp = c.open_sftp()

# Upload all .tex and .bib and .cls in PAPER
for f in os.listdir("PAPER"):
    if f.endswith(".tex") or f.endswith(".bib") or f.endswith(".cls"):
        local_path = os.path.join("PAPER", f)
        remote_path = f"/tmp/paper_build/{f}"
        sftp.put(local_path, remote_path)
        print(f"  Uploaded {f}")

# Upload figures
for fig in os.listdir("PAPER/figures"):
    local_path = os.path.join("PAPER/figures", fig)
    remote_path = f"/tmp/paper_build/figures/{fig}"
    sftp.put(local_path, remote_path)

print("[+] All files uploaded to /tmp/paper_build")

# Run pdflatex
print("Running pdflatex (Pass 1)...")
out1, err1 = run("cd /tmp/paper_build && pdflatex -interaction=nonstopmode MASTER_MANUSCRIPT_INTEGRATED.tex")

print("Running pdflatex (Pass 2)...")
out2, err2 = run("cd /tmp/paper_build && pdflatex -interaction=nonstopmode MASTER_MANUSCRIPT_INTEGRATED.tex")

# Check if PDF exists
check_out, _ = run("ls -l /tmp/paper_build/MASTER_MANUSCRIPT_INTEGRATED.pdf")
print("PDF Status:", check_out)

if "MASTER_MANUSCRIPT_INTEGRATED.pdf" in check_out:
    sftp.get("/tmp/paper_build/MASTER_MANUSCRIPT_INTEGRATED.pdf", "PAPER/MASTER_MANUSCRIPT_INTEGRATED.pdf")
    print("[+] Downloaded MASTER_MANUSCRIPT_INTEGRATED.pdf successfully!")
else:
    print("Compilation Log:\n", out2[-2000:])

sftp.close()
c.close()

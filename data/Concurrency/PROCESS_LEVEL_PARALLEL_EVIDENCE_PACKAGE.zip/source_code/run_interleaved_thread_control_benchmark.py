import os, paramiko, json

ssh_pass = os.getenv('VM_SSH_PASSWORD') or os.getenv('SSH_PASS')
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('192.168.160.129', username='osu', password=ssh_pass, timeout=15)

def run(cmd):
    stdin, stdout, stderr = c.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='ignore').strip()
    err = stderr.read().decode('utf-8', errors='ignore').strip()
    return out, err

# Script to run inside eval-server-central-4core
in_pod_script = """
import os, sys, time, json
import numpy as np
import joblib

# Load workload (1,000 vectors per service = 4,000 certified vectors)
with open('/tmp/test4_workload_1000.json') as f:
    workload = json.load(f)

# Load bundles
MODELS = {}
for s in ['productpage', 'details', 'reviews', 'ratings']:
    MODELS[s] = joblib.load(f'/app/models/{s}/{s}_bundle_7feat.joblib')

def run_single_eval(mode_name, n_jobs_val, thread_env_val):
    # Set thread environment for thread control
    for s in ['productpage', 'ratings']:
        MODELS[s]['model'].n_jobs = n_jobs_val
        
    t_start = time.perf_counter()
    per_service = {}
    
    for s in ['productpage', 'details', 'reviews', 'ratings']:
        b = MODELS[s]
        m = b['model']
        sc = b.get('scaler')
        X = sc.transform(workload[s]['vectors']) if sc else np.array(workload[s]['vectors'])
        t0 = time.perf_counter()
        if hasattr(m, 'predict_proba'):
            _ = m.predict_proba(X)
        else:
            _ = m.predict(X)
        per_service[s] = round((time.perf_counter() - t0) * 1000.0, 3)
        
    total_ms = round((time.perf_counter() - t_start) * 1000.0, 3)
    
    return {
        'timestamp': time.time(),
        'mode': mode_name,
        'n_jobs_rf': n_jobs_val,
        'thread_env': thread_env_val,
        'total_pure_makespan_ms': total_ms,
        'per_service_ms': per_service,
        'pure_throughput_vps': round(4000.0 / (total_ms / 1000.0), 1)
    }

# Warmup 2 cycles each
for _ in range(2):
    run_single_eval('warmup_default', -1, 'unconstrained')
    run_single_eval('warmup_single', 1, 'pinned_1')

# Interleaved 10 paired repetitions (20 runs total)
interleaved_runs = []
default_runs = []
single_runs = []

for rep in range(1, 11):
    # Default multi-thread (n_jobs=-1, OpenMP unconstrained)
    res_def = run_single_eval('default_multithread', -1, 'unconstrained_4cores')
    res_def['repetition'] = rep
    res_def['order_index'] = len(interleaved_runs) + 1
    interleaved_runs.append(res_def)
    default_runs.append(res_def)
    
    # Controlled single-thread (n_jobs=1, OpenMP pinned to 1)
    res_single = run_single_eval('controlled_singlethread', 1, 'pinned_single_thread')
    res_single['repetition'] = rep
    res_single['order_index'] = len(interleaved_runs) + 1
    interleaved_runs.append(res_single)
    single_runs.append(res_single)

# Summary statistics (N=10, ddof=1)
def calc_stats(vals):
    return {
        'mean': round(float(np.mean(vals)), 3),
        'std': round(float(np.std(vals, ddof=1)), 3),
        'min': round(float(np.min(vals)), 3),
        'median': round(float(np.median(vals)), 3),
        'max': round(float(np.max(vals)), 3)
    }

def_makespans = [r['total_pure_makespan_ms'] for r in default_runs]
single_makespans = [r['total_pure_makespan_ms'] for r in single_runs]
def_thrs = [r['pure_throughput_vps'] for r in default_runs]
single_thrs = [r['pure_throughput_vps'] for r in single_runs]

speedups_def_vs_single = [d / s for d, s in zip(def_makespans, single_makespans)]

output = {
    'metadata': {
        'description': 'Interleaved controlled threading benchmark on 4-core container (eval-server-central-4core)',
        'container_cpu_limit': '4000m (4.0 Cores)',
        'container_memory_limit': '8192Mi (8 GiB)',
        'vectors_per_trial': 4000,
        'repetitions': 10,
        'execution_pattern': 'Interleaved: Default, Single, Default, Single (20 consecutive executions)',
        'sample_std_ddof': 1
    },
    'summary': {
        'default_multithread_4core_makespan_ms': calc_stats(def_makespans),
        'controlled_singlethread_4core_makespan_ms': calc_stats(single_makespans),
        'default_multithread_4core_throughput_vps': calc_stats(def_thrs),
        'controlled_singlethread_4core_throughput_vps': calc_stats(single_thrs),
        'in_container_threading_penalty_ratio': calc_stats(speedups_def_vs_single)
    },
    'default_runs': default_runs,
    'single_thread_runs': single_runs,
    'interleaved_execution_sequence': interleaved_runs
}

with open('/tmp/test4_controlled_threading_interleaved_results.json', 'w') as f:
    json.dump(output, f, indent=2)

print(json.dumps(output['summary'], indent=2))
"""

sftp = c.open_sftp()
with sftp.open("/tmp/bench_interleaved.py", "w") as f:
    f.write(in_pod_script)
sftp.close()

run("kubectl cp /tmp/bench_interleaved.py default/eval-server-central-4core:/tmp/bench_interleaved.py")
out, err = run("kubectl exec eval-server-central-4core -- python3 /tmp/bench_interleaved.py")
print("BENCHMARK OUTPUT:\n", out)
if err:
    print("ERR:\n", err)

# Retrieve the JSON file
run("kubectl cp default/eval-server-central-4core:/tmp/test4_controlled_threading_interleaved_results.json /tmp/test4_controlled_threading_interleaved_results.json")
sftp = c.open_sftp()
local_dest = "scratch/test4_controlled_threading_interleaved_results.json"
sftp.get("/tmp/test4_controlled_threading_interleaved_results.json", local_dest)
sftp.close()
c.close()
print(f"[+] Retrieved {local_dest} successfully!")

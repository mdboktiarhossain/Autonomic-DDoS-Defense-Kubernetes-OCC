#!/usr/bin/env python3
import time, json, urllib.request, threading, os, sys
from concurrent.futures import ThreadPoolExecutor

POD_IPS = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
OUT_FILE = sys.argv[2] if len(sys.argv) > 2 else "/tmp/cpu_memory_samples.jsonl"
STOP_FILE = sys.argv[3] if len(sys.argv) > 3 else "/tmp/cgroup_sampler.stop"
INTERVAL_S = float(sys.argv[4]) if len(sys.argv) > 4 else 0.25

if os.path.exists(STOP_FILE):
    os.remove(STOP_FILE)

prev_stats = {}
executor = ThreadPoolExecutor(max_workers=4)

def sample_pod(svc, ip):
    url = f"http://{ip}:8080/api/cgroup_stat"
    try:
        t_req = time.time()
        with urllib.request.urlopen(url, timeout=1.0) as resp:
            data = json.loads(resp.read().decode())
        t_done = time.time()
        cpu_stat = data.get("cpu_stat", {})
        usage_usec = cpu_stat.get("usage_usec", 0)
        user_usec = cpu_stat.get("user_usec", 0)
        sys_usec = cpu_stat.get("system_usec", 0)
        throttled_usec = cpu_stat.get("throttled_usec", 0)
        nr_throttled = cpu_stat.get("nr_throttled", 0)
        mem_mb = data.get("memory_mb", 0.0)
        latest_c = data.get("latest_cycle", {})

        cpu_util_pct = 0.0
        if svc in prev_stats:
            p_usage, p_time = prev_stats[svc]
            dt = t_done - p_time
            if dt > 0:
                # 1 core = 1,000,000 usec/sec => (usage_diff / (dt * 1e6)) * 100%
                cpu_util_pct = ((usage_usec - p_usage) / (dt * 1000000.0)) * 100.0
        
        prev_stats[svc] = (usage_usec, t_done)

        return {
            "timestamp": t_done,
            "service": svc,
            "ip": ip,
            "cpu_util_pct": round(max(0.0, cpu_util_pct), 2),
            "usage_usec": usage_usec,
            "user_usec": user_usec,
            "sys_usec": sys_usec,
            "nr_throttled": nr_throttled,
            "throttled_usec": throttled_usec,
            "memory_mb": mem_mb,
            "latest_cycle_index": latest_c.get("cycle_index") if latest_c else None,
            "latest_attribution": latest_c.get("attribution") if latest_c else None,
            "is_attack": latest_c.get("is_attack", False) if latest_c else False
        }
    except Exception as e:
        return {"timestamp": time.time(), "service": svc, "error": str(e)}

with open(OUT_FILE, "w", encoding="utf-8") as f_out:
    while not os.path.exists(STOP_FILE):
        t_loop_s = time.time()
        futures = {executor.submit(sample_pod, svc, ip): svc for svc, ip in POD_IPS.items()}
        for fut in futures:
            rec = fut.result()
            f_out.write(json.dumps(rec) + "\n")
        f_out.flush()
        elapsed = time.time() - t_loop_s
        sleep_time = max(0.01, INTERVAL_S - elapsed)
        time.sleep(sleep_time)

executor.shutdown(wait=False)

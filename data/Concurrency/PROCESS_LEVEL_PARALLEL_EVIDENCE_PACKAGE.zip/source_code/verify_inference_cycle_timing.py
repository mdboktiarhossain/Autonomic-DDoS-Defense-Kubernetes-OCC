import json, os, sys

def audit_cycles_and_inferences():
    cycles_file = 'scratch/detection_cycles_attack.json'
    infs_file = 'scratch/inference_events_attack.json'
    
    if not os.path.exists(cycles_file):
        print(f"Error: {cycles_file} not found.")
        return
        
    data = json.load(open(cycles_file))
    print("=" * 80)
    print("INDEPENDENT AUDIT: DETECTION-CYCLE TIMING & INFERENCE TIMESTAMP ATTRIBUTION")
    print("=" * 80)
    
    total_cycles = 0
    total_inf_cycles = 0
    enclosed_inf_cycles = 0
    valid_exec_ids = 0
    
    all_cycles = []
    all_inferences = []
    
    for svc, info in data.items():
        cycs = info.get('cycles', [])
        total_cycles += len(cycs)
        print(f"\nService: {svc.upper()} ({len(cycs)} cycles recorded)")
        
        for c in cycs:
            c_start = c.get('cycle_start_time')
            c_end = c.get('cycle_completion_time')
            all_cycles.append((c_start, c_end, svc, c.get('cycle_index'), c.get('is_attack', False)))
            
            i_start = c.get('ml_inference_start')
            i_end = c.get('ml_inference_end')
            exec_id = c.get('exec_id')
            
            if i_start is not None and i_end is not None:
                total_inf_cycles += 1
                is_enclosed = (i_start >= c_start) and (i_end <= c_end)
                has_exec_id = bool(exec_id and exec_id.startswith(svc))
                
                if is_enclosed:
                    enclosed_inf_cycles += 1
                if has_exec_id:
                    valid_exec_ids += 1
                    
                all_inferences.append((i_start, i_end, svc, exec_id, c.get('cycle_index')))
                status = "PASS" if is_enclosed else "FAIL"
                print(f"  Cycle {c.get('cycle_index'):>3}: [{c_start:.4f}, {c_end:.4f}] | Inf: [{i_start:.4f}, {i_end:.4f}] -> {status} (exec_id={exec_id})")

    print("\n" + "-" * 80)
    print("CRITICAL FINDING A VERIFICATION SUMMARY:")
    print(f"  Total recorded detection cycles:       {total_cycles}")
    print(f"  Cycles with ML inference:              {total_inf_cycles}")
    print(f"  Inferences strictly enclosed in cycle: {enclosed_inf_cycles}/{total_inf_cycles} ({(enclosed_inf_cycles/total_inf_cycles*100) if total_inf_cycles else 0:.1f}%)")
    print(f"  Inferences with valid unique exec_id:  {valid_exec_ids}/{total_inf_cycles} ({(valid_exec_ids/total_inf_cycles*100) if total_inf_cycles else 0:.1f}%)")
    
    # Check overlapping detection cycles across services
    all_cycles.sort(key=lambda x: x[0])
    cycle_overlaps = 0
    cycle_overlap_pairs = []
    for i in range(len(all_cycles) - 1):
        c1 = all_cycles[i]
        c2 = all_cycles[i+1]
        # Overlap if c2 starts before c1 ends, and services differ
        if c2[0] < c1[1] and c1[2] != c2[2]:
            cycle_overlaps += 1
            cycle_overlap_pairs.append((c1, c2))
            
    print(f"\nCROSS-SERVICE PARALLEL CONCURRENCY:")
    print(f"  Overlapping cross-service cycle pairs: {cycle_overlaps}")
    for p1, p2 in cycle_overlap_pairs[:5]:
        overlap_ms = (min(p1[1], p2[1]) - max(p1[0], p2[0])) * 1000.0
        print(f"    Overlap: {p1[2]} (cycle {p1[3]}) & {p2[2]} (cycle {p2[3]}) -> {overlap_ms:.2f} ms concurrency")

    # Check overlapping inference operations
    all_inferences.sort(key=lambda x: x[0])
    inf_overlaps = 0
    for i in range(len(all_inferences) - 1):
        inf1 = all_inferences[i]
        inf2 = all_inferences[i+1]
        if inf2[0] < inf1[1] and inf1[2] != inf2[2]:
            inf_overlaps += 1
            print(f"    Overlapping ML Inference: {inf1[2]} ({inf1[3]}) & {inf2[2]} ({inf2[3]})")
            
    print(f"  Overlapping cross-service inference operations: {inf_overlaps}")
    print("=" * 80)

if __name__ == '__main__':
    audit_cycles_and_inferences()

import re, py_compile

with open('PAPER/SCENARIO_5_PATCHED_DEFENDER_HMAC_V2.py', 'r', encoding='utf-8') as f:
    text = f.read()

# 1. Add imports & telemetry globals after imports
import_insert = """
import collections, uuid
DETECTION_CYCLE_HISTORY = collections.deque(maxlen=2000)
INFERENCE_EVENT_HISTORY = collections.deque(maxlen=2000)
DETECTION_CYCLE_LOCK = threading.Lock()
"""
text = text.replace("from concurrent.futures import ThreadPoolExecutor, as_completed",
                    "from concurrent.futures import ThreadPoolExecutor, as_completed" + import_insert)

# 2. Add endpoints before @app.on_event("startup")
endpoints_insert = """
@app.get("/api/detection_cycles")
async def get_detection_cycles(limit: int = 1000):
    with DETECTION_CYCLE_LOCK:
        cycs = list(DETECTION_CYCLE_HISTORY)
    return JSONResponse(content={
        "service": MY_APP_LABEL,
        "total_recorded_cycles": len(cycs),
        "cycles": cycs[-limit:]
    })

@app.get("/api/inference_events")
async def get_inference_events(limit: int = 1000):
    with DETECTION_CYCLE_LOCK:
        infs = list(INFERENCE_EVENT_HISTORY)
    return JSONResponse(content={
        "service": MY_APP_LABEL,
        "total_recorded_inferences": len(infs),
        "inferences": infs[-limit:]
    })

@app.get("/api/cgroup_stat")
async def get_cgroup_stat():
    t_wall = time.time()
    cpu_stat = {}
    try:
        with open("/sys/fs/cgroup/cpu.stat", "r") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) == 2:
                    cpu_stat[parts[0]] = int(parts[1]) if parts[1].isdigit() else parts[1]
    except Exception as e:
        cpu_stat["error"] = str(e)
    mem_bytes = 0
    try:
        with open("/sys/fs/cgroup/memory.current", "r") as f:
            mem_bytes = int(f.read().strip())
    except Exception:
        pass
    with DETECTION_CYCLE_LOCK:
        latest_c = DETECTION_CYCLE_HISTORY[-1] if DETECTION_CYCLE_HISTORY else None
    return JSONResponse(content={
        "service": MY_APP_LABEL,
        "timestamp": t_wall,
        "cpu_stat": cpu_stat,
        "memory_bytes": mem_bytes,
        "memory_mb": round(mem_bytes / (1024 * 1024), 2),
        "latest_cycle": latest_c
    })

@app.post("/api/detection_cycles/clear")
async def clear_detection_cycles():
    with DETECTION_CYCLE_LOCK:
        DETECTION_CYCLE_HISTORY.clear()
        INFERENCE_EVENT_HISTORY.clear()
    try:
        with open("/app/detection_cycles.jsonl", "w") as f_cyc:
            f_cyc.write("")
    except Exception:
        pass
    return JSONResponse(content={"status": "cleared", "service": MY_APP_LABEL})

"""
text = text.replace('@app.on_event("startup")', endpoints_insert + '\n@app.on_event("startup")')

# 3. Update def run_l7_inference_cycle signature to accept cycle_inferences=None
text = text.replace("def run_l7_inference_cycle():", "def run_l7_inference_cycle(cycle_inferences=None):")

# 4. In Path A (replay inference), record exec_id, synchronous wall timestamps, and append to cycle_inferences:
target_replay = """            # ── PATH A: Controlled Dataset Replay Inference ─────────────────
            if replay_records and is_7feat_bundle:
                latest_replay = replay_records[-1]
                raw_x = np.array([latest_replay["values"]])
                scaler = bundle["scaler"]
                model = bundle["model"]
                t_inf_start = time.perf_counter()
                scaled_x = scaler.transform(raw_x)
                if hasattr(model, "predict_proba"):
                    prob_ddos = float(model.predict_proba(scaled_x)[0][1])
                else:
                    prob_ddos = float(model.predict(scaled_x)[0])
                inf_latency_ms = (time.perf_counter() - t_inf_start) * 1000.0"""

replace_replay = """            # ── PATH A: Controlled Dataset Replay Inference ─────────────────
            if replay_records and is_7feat_bundle:
                # Batch evaluation across all collected records for realistic multi-vector workload
                raw_x = np.array([r["values"] for r in replay_records])
                scaler = bundle["scaler"]
                model = bundle["model"]
                exec_id = f"{app_label}-inf-{uuid.uuid4().hex[:8]}"
                t_inf_wall_s = time.time()
                t_inf_start = time.perf_counter()
                scaled_x = scaler.transform(raw_x)
                if hasattr(model, "predict_proba"):
                    probs = model.predict_proba(scaled_x)
                    prob_ddos = float(probs[-1][1]) if (probs.ndim > 1 and probs.shape[1] > 1) else float(probs[-1])
                else:
                    preds = model.predict(scaled_x)
                    prob_ddos = float(preds[-1])
                inf_latency_ms = (time.perf_counter() - t_inf_start) * 1000.0
                t_inf_wall_e = time.time()
                
                inf_event = {
                    "exec_id": exec_id,
                    "service": app_label,
                    "t_start": t_inf_wall_s,
                    "t_end": t_inf_wall_e,
                    "duration_ms": round(inf_latency_ms, 3),
                    "model": bundle.get("architecture", type(model).__name__),
                    "records_analyzed": len(replay_records),
                    "source": "DATASET_REPLAY"
                }
                if cycle_inferences is not None:
                    cycle_inferences.append(inf_event)
                with DETECTION_CYCLE_LOCK:
                    INFERENCE_EVENT_HISTORY.append(inf_event)
                latest_replay = replay_records[-1]"""

text = text.replace(target_replay, replace_replay)

# 5. In Path B (live ingress inference), also record exec_id and synchronous wall timestamps:
target_live = """            inf_df = features[expected_feats].copy()
            scaled_df = pd.DataFrame(scaler.transform(inf_df), columns=expected_feats, index=inf_df.index)

            t_inf_start = time.perf_counter()
            scaled_df = pd.DataFrame(scaler.transform(inf_df), columns=expected_feats, index=inf_df.index)
            preds = model.predict(scaled_df)
            probs = model.predict_proba(scaled_df) if hasattr(model, "predict_proba") else None
            prob_ddos = float(probs[-1][1]) if (probs is not None and probs.shape[1] > 1) else (1.0 if int(preds[-1]) == 1 else 0.0)
            inf_latency_ms = (time.perf_counter() - t_inf_start) * 1000.0"""

replace_live = """            inf_df = features[expected_feats].copy()
            exec_id = f"{app_label}-inf-{uuid.uuid4().hex[:8]}"
            t_inf_wall_s = time.time()
            t_inf_start = time.perf_counter()
            scaled_df = pd.DataFrame(scaler.transform(inf_df), columns=expected_feats, index=inf_df.index)
            preds = model.predict(scaled_df)
            probs = model.predict_proba(scaled_df) if hasattr(model, "predict_proba") else None
            prob_ddos = float(probs[-1][1]) if (probs is not None and probs.shape[1] > 1) else (1.0 if int(preds[-1]) == 1 else 0.0)
            inf_latency_ms = (time.perf_counter() - t_inf_start) * 1000.0
            t_inf_wall_e = time.time()
            
            inf_event = {
                "exec_id": exec_id,
                "service": app_label,
                "t_start": t_inf_wall_s,
                "t_end": t_inf_wall_e,
                "duration_ms": round(inf_latency_ms, 3),
                "model": bundle.get("architecture", type(model).__name__),
                "records_analyzed": len(features),
                "source": "LIVE_INGRESS"
            }
            if cycle_inferences is not None:
                cycle_inferences.append(inf_event)
            with DETECTION_CYCLE_LOCK:
                INFERENCE_EVENT_HISTORY.append(inf_event)"""

text = text.replace(target_live, replace_live)

# 6. In detection_loop:
# Start detection cycle at the top of the while True loop, before run_l7_inference_cycle!
target_loop_top = """    while True:
        try:
            now = time.time()

            # ── 1. Fast L7 Inference Cycle (every L7_INFERENCE_INTERVAL, e.g. 2s) ───
            if ENABLE_L7_INFERENCE and (now - last_l7_time) >= L7_INFERENCE_INTERVAL:
                last_l7_time = now
                run_l7_inference_cycle()"""

replace_loop_top = """    while True:
        try:
            t_cycle_start = time.time()
            now = t_cycle_start
            cycle_inferences = []

            # ── 1. Fast L7 Inference Cycle (every L7_INFERENCE_INTERVAL, e.g. 2s) ───
            if ENABLE_L7_INFERENCE and (now - last_l7_time) >= L7_INFERENCE_INTERVAL:
                last_l7_time = now
                run_l7_inference_cycle(cycle_inferences)"""

text = text.replace(target_loop_top, replace_loop_top)

# At decision point: record t_decision
target_decision = """                STATE["hybrid_attribution"][app_label] = {
                    "attribution": attribution,"""

replace_decision = """                t_decision = time.time()
                STATE["hybrid_attribution"][app_label] = {
                    "attribution": attribution,"""

text = text.replace(target_decision, replace_decision)

# At end of per-service loop: record t_cycle_end and cyc_rec
target_loop_end = """                    any_mitigated = True
                    dispatch_mitigation(app_label, dispatch_attr, target_identity=target_identity)"""

replace_loop_end = """                    any_mitigated = True
                    dispatch_mitigation(app_label, dispatch_attr, target_identity=target_identity)

                t_cycle_end = time.time()
                latest_inf = cycle_inferences[-1] if cycle_inferences else None
                cyc_rec = {
                    "cycle_index": len(DETECTION_CYCLE_HISTORY) + 1,
                    "service": app_label,
                    "cycle_start_time": t_cycle_start,
                    "cycle_completion_time": t_cycle_end,
                    "cycle_duration_ms": round((t_cycle_end - t_cycle_start) * 1000.0, 3),
                    "decision_time": t_decision,
                    "exec_id": latest_inf["exec_id"] if latest_inf else None,
                    "ml_inference_start": latest_inf["t_start"] if latest_inf else None,
                    "ml_inference_end": latest_inf["t_end"] if latest_inf else None,
                    "inference_latency_ms": latest_inf["duration_ms"] if latest_inf else None,
                    "records_analyzed": latest_inf["records_analyzed"] if latest_inf else 0,
                    "source": latest_inf["source"] if latest_inf else "IDLE",
                    "attribution": attribution,
                    "rps_positive": rps_positive,
                    "ml_positive": ml_positive,
                    "stage3b_positive": stage3b_positive,
                    "is_attack": (attribution in ("BOTH", "ML_ONLY", "STAGE3B_ONLY", "RPS_ONLY")),
                    "inferences": list(cycle_inferences)
                }
                with DETECTION_CYCLE_LOCK:
                    DETECTION_CYCLE_HISTORY.append(cyc_rec)
                
                try:
                    with open("/app/detection_cycles.jsonl", "a") as f_cyc:
                        f_cyc.write(json.dumps(cyc_rec) + "\\n")
                except Exception:
                    pass
                
                if latest_inf or cyc_rec["is_attack"]:
                    logging.info(
                        f"[CYCLE-EVENT] cycle={cyc_rec['cycle_index']} svc={app_label} attr={attribution} "
                        f"dur={cyc_rec['cycle_duration_ms']:.2f}ms "
                        f"t_start={t_cycle_start:.6f} t_end={t_cycle_end:.6f} "
                        f"inf_exec={latest_inf['exec_id'] if latest_inf else 'NONE'}"
                    )"""

text = text.replace(target_loop_end, replace_loop_end)

with open('scratch/instrumented_defender.py', 'w', encoding='utf-8') as f:
    f.write(text)

py_compile.compile('scratch/instrumented_defender.py', doraise=True)
print("[+] SUCCESS: scratch/instrumented_defender.py generated and compiled cleanly!")

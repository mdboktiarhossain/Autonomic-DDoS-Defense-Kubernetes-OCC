import http.server, socketserver, json, time, joblib, sys, os, uuid
import numpy as np

PORT = 8081

# Determine service from environment or argument
SERVICE_NAME = sys.argv[1] if len(sys.argv) > 1 else os.getenv("MY_APP_LABEL", "productpage")
if SERVICE_NAME == "product":
    SERVICE_NAME = "productpage"

print(f"[+] Initializing Evaluation Server for service '{SERVICE_NAME}' on port {PORT}...")

MODELS = {}
for s in ['productpage', 'details', 'reviews', 'ratings']:
    try:
        MODELS[s] = joblib.load(f'/app/models/{s}/{s}_bundle_7feat.joblib')
        print(f"  Loaded model for {s}: {MODELS[s]['model'].__class__.__name__}")
    except Exception as e:
        print(f"  Warning: could not load model for {s}: {e}")

def run_inference(svc, vectors):
    b = MODELS[svc]
    m = b['model']
    sc = b.get('scaler')
    thresh = b.get('threshold', 0.7)
    
    exec_id = f"{svc}-eval-{uuid.uuid4().hex[:8]}"
    t0_epoch = time.time()
    t0_wall = time.perf_counter()
    t0_cpu = time.process_time()
    
    # Feature scaling
    X = sc.transform(vectors) if sc else np.array(vectors)
    
    # Batch predict
    if hasattr(m, 'predict_proba'):
        probs = m.predict_proba(X)[:, 1]
        preds = (probs >= thresh).astype(int)
    else:
        preds = m.predict(X)
        probs = preds.astype(float)
        
    t1_wall = time.perf_counter()
    t1_cpu = time.process_time()
    t1_epoch = time.time()
    
    wall_ms = (t1_wall - t0_wall) * 1000.0
    cpu_ms = (t1_cpu - t0_cpu) * 1000.0
    
    return {
        'exec_id': exec_id,
        'service': svc,
        'count': len(vectors),
        't_start': t0_epoch,
        't_end': t1_epoch,
        'wall_ms': round(wall_ms, 3),
        'cpu_ms': round(cpu_ms, 3),
        'throughput_vps': round(len(vectors) / (t1_wall - t0_wall), 1) if (t1_wall - t0_wall) > 0 else 0,
        'mean_sample_latency_us': round((wall_ms / len(vectors)) * 1000.0, 2),
        'attack_detections': int(np.sum(preds == 1)),
        'benign_detections': int(np.sum(preds == 0))
    }

class BenchmarkHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass # Suppress noisy request logging

    def do_POST(self):
        content_len = int(self.headers.get('Content-Length', 0))
        post_body = self.rfile.read(content_len)
        data = json.loads(post_body.decode('utf-8'))
        
        if self.path == '/evaluate_single':
            # Single service evaluation (for parallel execution)
            svc = data.get('service', SERVICE_NAME)
            vectors = data.get('vectors', [])
            res = run_inference(svc, vectors)
            self._send_json(res)
            
        elif self.path == '/evaluate_sequential':
            # Sequential evaluation of all 4 services (for sequential baseline)
            # data is a dict: {'productpage': [...], 'details': [...], 'reviews': [...], 'ratings': [...]}
            seq_exec_id = f"seq-eval-{uuid.uuid4().hex[:8]}"
            t0_epoch = time.time()
            t0_wall = time.perf_counter()
            t0_cpu = time.process_time()
            all_res = {}
            for s in ['productpage', 'details', 'reviews', 'ratings']:
                vecs = data.get(s, [])
                all_res[s] = run_inference(s, vecs)
            t1_wall = time.perf_counter()
            t1_cpu = time.process_time()
            t1_epoch = time.time()
            
            total_wall_ms = (t1_wall - t0_wall) * 1000.0
            total_cpu_ms = (t1_cpu - t0_cpu) * 1000.0
            total_vectors = sum(r['count'] for r in all_res.values())
            
            self._send_json({
                'exec_id': seq_exec_id,
                'mode': 'sequential_baseline',
                't_start': t0_epoch,
                't_end': t1_epoch,
                'total_vectors': total_vectors,
                'total_wall_ms': round(total_wall_ms, 3),
                'total_cpu_ms': round(total_cpu_ms, 3),
                'aggregate_throughput_vps': round(total_vectors / (total_wall_ms / 1000.0), 1),
                'per_service': all_res
            })
        else:
            self.send_response(404)
            self.end_headers()

    def do_GET(self):
        if self.path == '/health':
            self._send_json({'status': 'ok', 'service': SERVICE_NAME})
        else:
            self.send_response(404)
            self.end_headers()

    def _send_json(self, obj):
        body = json.dumps(obj).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

if __name__ == '__main__':
    server = ThreadedHTTPServer(('0.0.0.0', PORT), BenchmarkHandler)
    print(f"[+] Evaluation Server ready on port {PORT}. Waiting for benchmark requests...")
    server.serve_forever()

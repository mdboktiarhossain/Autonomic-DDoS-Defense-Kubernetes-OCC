import http.client, json, time, os, sys
from concurrent.futures import ThreadPoolExecutor
import numpy as np

# Configuration with verified dynamic Pod IPs
POD_IPS = {
    'productpage': '10.244.2.41',
    'details':     '10.244.2.43',
    'reviews':     '10.244.2.40',
    'ratings':     '10.244.2.42'
}
CENTRAL_4CORE_IP = '10.244.2.39'
CENTRAL_1CORE_IP = '10.244.2.41' # 1.0 Core Reference (limits.cpu: 1000m)
PORT = 8081

WORKLOAD_FILE = '/home/osu/ddos_detector/test4_workload_1000.json'
N_REPETITIONS = 10

print("=" * 80)
print(f"TEST 4: EMPIRICAL VALIDATION OF PROCESS-LEVEL PARALLEL EXECUTION ({N_REPETITIONS} REPETITIONS)")
print("Resource-Matched Benchmark: Decentralized Parallel (4x1-core) vs Centralized Sequential (4-core & 1-core)")
print("=" * 80)

# Load certified workload
workload = json.load(open(WORKLOAD_FILE))
total_vectors_per_trial = sum(workload[s]['count'] for s in POD_IPS)
print(f"[+] Loaded certified workload: 1,000 vectors/service ({total_vectors_per_trial} total/rep)")

# Pre-encode JSON payloads so serialization is NOT measured in execution time
preencoded_single = {
    svc: json.dumps({'service': svc, 'vectors': workload[svc]['vectors']}).encode('utf-8')
    for svc in POD_IPS
}
preencoded_sequential = json.dumps({s: workload[s]['vectors'] for s in POD_IPS}).encode('utf-8')

headers = {'Content-Type': 'application/json'}

def query_service(svc):
    body = preencoded_single[svc]
    ip = POD_IPS[svc]
    conn = http.client.HTTPConnection(ip, PORT, timeout=15.0)
    t0 = time.perf_counter()
    conn.request('POST', '/evaluate_single', body, headers)
    resp = conn.getresponse()
    data = resp.read()
    t1 = time.perf_counter()
    conn.close()
    
    res = json.loads(data.decode('utf-8'))
    res['roundtrip_wall_ms'] = round((t1 - t0) * 1000.0, 3)
    return res

def run_parallel_iteration():
    t_dispatch_epoch = time.time()
    t_dispatch = time.perf_counter()
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {svc: pool.submit(query_service, svc) for svc in POD_IPS}
        results = {svc: futures[svc].result() for svc in POD_IPS}
    t_complete = time.perf_counter()
    t_complete_epoch = time.time()
    
    # Directly timed global inference makespan (end-to-end roundtrip)
    t_makespan_e2e_ms = (t_complete - t_dispatch) * 1000.0
    
    # Directly timed cluster pure inference makespan across all 4 pods
    min_inf_start = min(r['t_start'] for r in results.values())
    max_inf_end = max(r['t_end'] for r in results.values())
    t_makespan_pure_ms = (max_inf_end - min_inf_start) * 1000.0
    max_internal_wall_ms = max(r['wall_ms'] for r in results.values())
    total_cpu_ms = sum(r['cpu_ms'] for r in results.values())
    
    e2e_throughput = total_vectors_per_trial / (t_makespan_e2e_ms / 1000.0)
    pure_throughput = total_vectors_per_trial / (t_makespan_pure_ms / 1000.0)
    
    return {
        'mode': 'decentralized_parallel',
        't_dispatch': t_dispatch_epoch,
        't_complete': t_complete_epoch,
        'roundtrip_wall_ms': round(t_makespan_e2e_ms, 3),
        'pure_makespan_ms': round(t_makespan_pure_ms, 3),
        'max_internal_wall_ms': round(max_internal_wall_ms, 3),
        'total_cpu_ms': round(total_cpu_ms, 3),
        'e2e_throughput_vps': round(e2e_throughput, 1),
        'pure_throughput_vps': round(pure_throughput, 1),
        'throughput_vps': round(pure_throughput, 1),
        'per_service': results
    }

def run_sequential_iteration(target_ip, label):
    body = preencoded_sequential
    conn = http.client.HTTPConnection(target_ip, PORT, timeout=25.0)
    t0_epoch = time.time()
    t0 = time.perf_counter()
    conn.request('POST', '/evaluate_sequential', body, headers)
    resp = conn.getresponse()
    data = resp.read()
    t1 = time.perf_counter()
    t1_epoch = time.time()
    conn.close()
    
    res = json.loads(data.decode('utf-8'))
    t_e2e_ms = (t1 - t0) * 1000.0
    res['roundtrip_wall_ms'] = round(t_e2e_ms, 3)
    res['t_dispatch'] = t0_epoch
    res['t_complete'] = t1_epoch
    res['e2e_throughput_vps'] = round(total_vectors_per_trial / (t_e2e_ms / 1000.0), 1)
    res['pure_throughput_vps'] = res.get('aggregate_throughput_vps', 0.0)
    res['benchmark_target'] = label
    return res

# Warm-up runs
print("\n[+] Performing 3 warm-up iterations to establish cache...")
for _ in range(3):
    _ = run_parallel_iteration()
    _ = run_sequential_iteration(CENTRAL_4CORE_IP, "centralized_4core")
    _ = run_sequential_iteration(CENTRAL_1CORE_IP, "centralized_1core")
print("[+] Warm-up completed successfully.")

# Execution loop
trials = []
print(f"\n[+] Executing {N_REPETITIONS} repetitions of Parallel vs Sequential (4-Core & 1-Core)...")

for rep in range(1, N_REPETITIONS + 1):
    # Interleave order to eliminate thermal or sequence bias
    if rep % 2 == 1:
        par_res = run_parallel_iteration()
        time.sleep(0.02)
        seq4_res = run_sequential_iteration(CENTRAL_4CORE_IP, "centralized_4core")
        time.sleep(0.02)
        seq1_res = run_sequential_iteration(CENTRAL_1CORE_IP, "centralized_1core")
    else:
        seq1_res = run_sequential_iteration(CENTRAL_1CORE_IP, "centralized_1core")
        time.sleep(0.02)
        seq4_res = run_sequential_iteration(CENTRAL_4CORE_IP, "centralized_4core")
        time.sleep(0.02)
        par_res = run_parallel_iteration()
        
    t_par_e2e = par_res['roundtrip_wall_ms']
    t_par_pure = par_res['pure_makespan_ms']
    t_par_exec = par_res['max_internal_wall_ms']
    
    t_seq4_e2e = seq4_res['roundtrip_wall_ms']
    t_seq4_exec = seq4_res['total_wall_ms']
    
    t_seq1_e2e = seq1_res['roundtrip_wall_ms']
    t_seq1_exec = seq1_res['total_wall_ms']
    
    # Speedups vs 4-Core Resource-Matched Centralized Baseline
    speedup_e2e_4core = t_seq4_e2e / t_par_e2e
    speedup_exec_4core = t_seq4_exec / t_par_pure
    efficiency_4core = speedup_e2e_4core / 4.0
    
    # Speedups vs 1-Core Reference Baseline
    speedup_e2e_1core = t_seq1_e2e / t_par_e2e
    speedup_exec_1core = t_seq1_exec / t_par_pure
    
    trial = {
        'repetition': rep,
        # Parallel (4x1-core)
        'parallel_roundtrip_ms': t_par_e2e,
        'parallel_pure_makespan_ms': t_par_pure,
        'parallel_max_internal_ms': t_par_exec,
        'parallel_cpu_ms': par_res['total_cpu_ms'],
        'parallel_pure_throughput_vps': par_res['pure_throughput_vps'],
        'parallel_e2e_throughput_vps': par_res['e2e_throughput_vps'],
        
        # Centralized 4-Core (Resource-Matched)
        'sequential_4core_roundtrip_ms': t_seq4_e2e,
        'sequential_4core_internal_ms': t_seq4_exec,
        'sequential_4core_cpu_ms': seq4_res['total_cpu_ms'],
        'sequential_4core_pure_throughput_vps': seq4_res['pure_throughput_vps'],
        'sequential_4core_e2e_throughput_vps': seq4_res['e2e_throughput_vps'],
        'speedup_4core_e2e': round(speedup_e2e_4core, 3),
        'speedup_4core_exec': round(speedup_exec_4core, 3),
        'efficiency_4core': round(efficiency_4core, 4),
        
        # Centralized 1-Core (Reference Baseline)
        'sequential_1core_roundtrip_ms': t_seq1_e2e,
        'sequential_1core_internal_ms': t_seq1_exec,
        'sequential_1core_cpu_ms': seq1_res['total_cpu_ms'],
        'sequential_1core_pure_throughput_vps': seq1_res['pure_throughput_vps'],
        'sequential_1core_e2e_throughput_vps': seq1_res['e2e_throughput_vps'],
        'speedup_1core_e2e': round(speedup_e2e_1core, 3),
        'speedup_1core_exec': round(speedup_exec_1core, 3),
        
        # Backward-compatibility aliases
        'sequential_roundtrip_ms': t_seq4_e2e,
        'sequential_internal_ms': t_seq4_exec,
        'sequential_cpu_ms': seq4_res['total_cpu_ms'],
        'sequential_throughput_vps': seq4_res['pure_throughput_vps'],
        'speedup_e2e': round(speedup_e2e_4core, 3),
        'speedup_exec': round(speedup_exec_4core, 3),
        'efficiency': round(efficiency_4core, 4),
        
        'parallel_details': par_res,
        'sequential_4core_details': seq4_res,
        'sequential_1core_details': seq1_res
    }
    trials.append(trial)
    print(f"  Rep {rep:>2}/{N_REPETITIONS}: Par(makespan)={t_par_pure:>5.2f} ms (e2e {t_par_e2e:>5.2f}) | "
          f"Seq-4Core={t_seq4_exec:>5.2f} ms (e2e {t_seq4_e2e:>5.2f}) -> Speedup={speedup_exec_4core:>4.2f}x (e2e: {speedup_e2e_4core:>4.2f}x) | "
          f"Seq-1Core={t_seq1_exec:>5.2f} ms -> Speedup={speedup_exec_1core:>4.2f}x")
    time.sleep(0.05)

# Helper for sample statistics with ddof=1
def compute_stats(vals):
    return {
        'mean': round(float(np.mean(vals)), 3),
        'std': round(float(np.std(vals, ddof=1)), 3),
        'min': round(float(np.min(vals)), 3),
        'median': round(float(np.median(vals)), 3),
        'max': round(float(np.max(vals)), 3)
    }

# Summary Statistics (using ddof=1)
par_e2e_vals        = [t['parallel_roundtrip_ms'] for t in trials]
par_pure_vals       = [t['parallel_pure_makespan_ms'] for t in trials]
par_exec_vals       = [t['parallel_max_internal_ms'] for t in trials]
par_pure_thrs       = [t['parallel_pure_throughput_vps'] for t in trials]
par_e2e_thrs        = [t['parallel_e2e_throughput_vps'] for t in trials]

seq4_e2e_vals       = [t['sequential_4core_roundtrip_ms'] for t in trials]
seq4_exec_vals      = [t['sequential_4core_internal_ms'] for t in trials]
seq4_pure_thrs      = [t['sequential_4core_pure_throughput_vps'] for t in trials]
seq4_e2e_thrs       = [t['sequential_4core_e2e_throughput_vps'] for t in trials]
speedups_4core_exec = [t['speedup_4core_exec'] for t in trials]
speedups_4core_e2e  = [t['speedup_4core_e2e'] for t in trials]
effs_4core          = [t['efficiency_4core'] for t in trials]

seq1_e2e_vals       = [t['sequential_1core_roundtrip_ms'] for t in trials]
seq1_exec_vals      = [t['sequential_1core_internal_ms'] for t in trials]
seq1_pure_thrs      = [t['sequential_1core_pure_throughput_vps'] for t in trials]
seq1_e2e_thrs       = [t['sequential_1core_e2e_throughput_vps'] for t in trials]
speedups_1core_exec = [t['speedup_1core_exec'] for t in trials]
speedups_1core_e2e  = [t['speedup_1core_e2e'] for t in trials]

summary = {
    'workload_vectors_per_service': 1000,
    'total_vectors_per_trial': 4000,
    'repetitions': N_REPETITIONS,
    'sample_std_ddof': 1,
    'cpu_configuration': {
        'decentralized_parallel': '4 Pods x 1.0 Core (4.0 Cores Aggregate, limits.cpu: 1000m each)',
        'centralized_sequential_4core': '1 Pod x 4.0 Cores (4.0 Cores Aggregate, limits.cpu: 4000m, Resource-Matched)',
        'centralized_sequential_1core': '1 Pod x 1.0 Core (1.0 Core Reference, limits.cpu: 1000m)'
    },
    'parallel_pure_makespan_ms': compute_stats(par_pure_vals),
    'parallel_roundtrip_e2e_ms': compute_stats(par_e2e_vals),
    'parallel_pure_throughput_vps': compute_stats(par_pure_thrs),
    'parallel_e2e_throughput_vps': compute_stats(par_e2e_thrs),
    
    'sequential_4core_internal_exec_ms': compute_stats(seq4_exec_vals),
    'sequential_4core_roundtrip_e2e_ms': compute_stats(seq4_e2e_vals),
    'sequential_4core_pure_throughput_vps': compute_stats(seq4_pure_thrs),
    'sequential_4core_e2e_throughput_vps': compute_stats(seq4_e2e_thrs),
    
    'speedup_4core_pure_exec': compute_stats(speedups_4core_exec),
    'speedup_4core_roundtrip_e2e': compute_stats(speedups_4core_e2e),
    'efficiency_4core': compute_stats(effs_4core),
    
    'sequential_1core_internal_exec_ms': compute_stats(seq1_exec_vals),
    'sequential_1core_roundtrip_e2e_ms': compute_stats(seq1_e2e_vals),
    'sequential_1core_pure_throughput_vps': compute_stats(seq1_pure_thrs),
    'sequential_1core_e2e_throughput_vps': compute_stats(seq1_e2e_thrs),
    
    'speedup_1core_pure_exec': compute_stats(speedups_1core_exec),
    'speedup_1core_roundtrip_e2e': compute_stats(speedups_1core_e2e),
    
    # Backward compatibility mappings
    'parallel_roundtrip_ms': compute_stats(par_e2e_vals),
    'sequential_roundtrip_ms': compute_stats(seq4_e2e_vals),
    'parallel_internal_exec_ms': compute_stats(par_pure_vals),
    'sequential_internal_exec_ms': compute_stats(seq4_exec_vals),
    'speedup_roundtrip_e2e': compute_stats(speedups_4core_e2e),
    'speedup_internal_exec': compute_stats(speedups_4core_exec),
    'efficiency': compute_stats(effs_4core),
    'parallel_throughput_vps': compute_stats(par_pure_thrs),
    'sequential_throughput_vps': compute_stats(seq4_pure_thrs)
}

final_output = {
    'summary': summary,
    'trials': trials
}

output_path = '/home/osu/ddos_detector/test4_parallel_vs_sequential_results.json'
with open(output_path, 'w', encoding='utf-8') as f:
    json.dump(final_output, f, indent=2)

print(f"\n[+] Results saved successfully to {output_path}!")
print("=" * 80)
print(f"RESOURCE-MATCHED COMPARISON (4-Core Parallel vs 4-Core Sequential, N={N_REPETITIONS}, ddof=1):")
print(f"  Pure Inference Makespan:  Parallel={summary['parallel_pure_makespan_ms']['mean']:.2f} \u00b1 {summary['parallel_pure_makespan_ms']['std']:.2f} ms | "
      f"Seq-4Core={summary['sequential_4core_internal_exec_ms']['mean']:.2f} \u00b1 {summary['sequential_4core_internal_exec_ms']['std']:.2f} ms -> "
      f"Speedup: {summary['speedup_4core_pure_exec']['mean']:.2f}x \u00b1 {summary['speedup_4core_pure_exec']['std']:.2f}x")
print(f"  End-to-End Makespan:      Parallel={summary['parallel_roundtrip_e2e_ms']['mean']:.2f} \u00b1 {summary['parallel_roundtrip_e2e_ms']['std']:.2f} ms | "
      f"Seq-4Core={summary['sequential_4core_roundtrip_e2e_ms']['mean']:.2f} \u00b1 {summary['sequential_4core_roundtrip_e2e_ms']['std']:.2f} ms -> "
      f"Speedup: {summary['speedup_4core_roundtrip_e2e']['mean']:.2f}x \u00b1 {summary['speedup_4core_roundtrip_e2e']['std']:.2f}x")
print(f"  Pure Throughput:          Parallel={summary['parallel_pure_throughput_vps']['mean']:,.1f} \u00b1 {summary['parallel_pure_throughput_vps']['std']:,.1f} vps | "
      f"Seq-4Core={summary['sequential_4core_pure_throughput_vps']['mean']:,.1f} \u00b1 {summary['sequential_4core_pure_throughput_vps']['std']:,.1f} vps")
print("=" * 80)
print(f"HARDWARE-SCALING COMPARISON (4-Core Parallel vs 1-Core Sequential, N={N_REPETITIONS}, ddof=1):")
print(f"  Pure Inference Makespan:  Parallel={summary['parallel_pure_makespan_ms']['mean']:.2f} \u00b1 {summary['parallel_pure_makespan_ms']['std']:.2f} ms | "
      f"Seq-1Core={summary['sequential_1core_internal_exec_ms']['mean']:.2f} \u00b1 {summary['sequential_1core_internal_exec_ms']['std']:.2f} ms -> "
      f"Speedup: {summary['speedup_1core_pure_exec']['mean']:.2f}x \u00b1 {summary['speedup_1core_pure_exec']['std']:.2f}x")
print(f"  End-to-End Makespan:      Parallel={summary['parallel_roundtrip_e2e_ms']['mean']:.2f} \u00b1 {summary['parallel_roundtrip_e2e_ms']['std']:.2f} ms | "
      f"Seq-1Core={summary['sequential_1core_roundtrip_e2e_ms']['mean']:.2f} \u00b1 {summary['sequential_1core_roundtrip_e2e_ms']['std']:.2f} ms -> "
      f"Speedup: {summary['speedup_1core_roundtrip_e2e']['mean']:.2f}x \u00b1 {summary['speedup_1core_roundtrip_e2e']['std']:.2f}x")
print("=" * 80)

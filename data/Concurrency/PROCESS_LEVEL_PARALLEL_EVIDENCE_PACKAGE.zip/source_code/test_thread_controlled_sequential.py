import os, paramiko

ssh_pass = os.getenv('VM_SSH_PASSWORD') or os.getenv('SSH_PASS')
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
c.connect('192.168.160.129', username='osu', password=ssh_pass, timeout=15)

def run(cmd):
    stdin, stdout, stderr = c.exec_command(cmd)
    out = stdout.read().decode('utf-8', errors='ignore').strip()
    err = stderr.read().decode('utf-8', errors='ignore').strip()
    return out, err

run("kubectl cp /home/osu/ddos_detector/test4_workload_1000.json default/eval-server-central-4core:/tmp/test4_workload_1000.json")

code = """
import joblib, time, json
import numpy as np

workload = json.load(open('/tmp/test4_workload_1000.json'))

MODELS = {}
for s in ['productpage', 'details', 'reviews', 'ratings']:
    MODELS[s] = joblib.load(f'/app/models/{s}/{s}_bundle_7feat.joblib')

def benchmark(n_jobs_override=None):
    for s in ['productpage', 'ratings']:
        if n_jobs_override is not None:
            MODELS[s]['model'].n_jobs = n_jobs_override
            
    t0 = time.perf_counter()
    per_s = {}
    for s in ['productpage', 'details', 'reviews', 'ratings']:
        b = MODELS[s]
        m = b['model']
        sc = b.get('scaler')
        X = sc.transform(workload[s]['vectors']) if sc else np.array(workload[s]['vectors'])
        t_s = time.perf_counter()
        if hasattr(m, 'predict_proba'):
            _ = m.predict_proba(X)
        else:
            _ = m.predict(X)
        per_s[s] = round((time.perf_counter() - t_s) * 1000.0, 3)
    total_ms = round((time.perf_counter() - t0) * 1000.0, 3)
    return total_ms, per_s

# Warmup
for _ in range(2):
    benchmark(-1)
    benchmark(1)

# Measure 10 runs each
results_default = [benchmark(-1) for _ in range(10)]
results_single_thread = [benchmark(1) for _ in range(10)]

mean_def = np.mean([r[0] for r in results_default])
std_def = np.std([r[0] for r in results_default], ddof=1)
mean_st = np.mean([r[0] for r in results_single_thread])
std_st = np.std([r[0] for r in results_single_thread], ddof=1)

print('=== 4-CORE CONTAINER INFERENCE BENCHMARK ===')
print(f'Default (n_jobs=-1, multi-thread on 4 cores): {mean_def:.2f} +/- {std_def:.2f} ms')
print(f'  Breakdown: {results_default[0][1]}')
print(f'Controlled Single-Thread (n_jobs=1 on 4 cores): {mean_st:.2f} +/- {std_st:.2f} ms')
print(f'  Breakdown: {results_single_thread[0][1]}')
"""

sftp = c.open_sftp()
with sftp.open("/tmp/bench_threads.py", "w") as f:
    f.write(code)
sftp.close()

run("kubectl cp /tmp/bench_threads.py default/eval-server-central-4core:/tmp/bench_threads.py")
out, err = run("kubectl exec eval-server-central-4core -- python3 /tmp/bench_threads.py")
print("OUT:\n", out)
if err:
    print("ERR:\n", err)
c.close()

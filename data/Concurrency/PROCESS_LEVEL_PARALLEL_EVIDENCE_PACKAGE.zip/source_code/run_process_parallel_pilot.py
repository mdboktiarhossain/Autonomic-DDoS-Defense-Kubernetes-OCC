import os, sys, time, json, paramiko

os.environ['SSH_PASS'] = os.getenv('VM_SSH_PASSWORD', '')
sys.path.insert(0, 'PAPER/Backup')
import run_scenario5_concurrent_harness as h

print("================================================================================")
print("PROCESS-LEVEL PARALLEL EXECUTION: SYNCHRONIZED 160-RPS PILOT 3 (INSTRUMENTED)")
print("================================================================================")

# 1. Global Preflight Check
print("[+] Running global preflight check...", flush=True)
pre = h.run_global_preflight()
print("[+] Preflight PASSED! All 4 defenders and resources are healthy.", flush=True)

# 2. Get Defender Pod IPs and clear cycle history
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect(h.SSH_HOST, username=h.SSH_USER, password=h.SSH_PASS, timeout=15)

def run_vm(cmd):
    stdin, stdout, stderr = ssh.exec_command(cmd)
    return stdout.read().decode('utf-8', errors='ignore').strip()

pod_data = json.loads(run_vm("kubectl get pods -n default -o json"))
pod_ips = {}
for p in pod_data['items']:
    name = p['metadata']['name']
    if 'ddos-defender' in name and 'central' not in name:
        svc = name.split('-')[2]
        if svc == 'product':
            svc = 'productpage'
        pod_ips[svc] = p['status'].get('podIP')

print(f"[+] Discovered defender pod IPs: {pod_ips}", flush=True)

# Clear cycle and inference buffers on all defenders
print("[+] Clearing detection cycle and inference history on all defenders...", flush=True)
for svc, ip in pod_ips.items():
    res = run_vm(f"curl -s -X POST http://{ip}:8080/api/detection_cycles/clear")
    print(f"  Cleared {svc} ({ip}): {res}", flush=True)
print("[+] Detection cycle and inference buffers cleared cleanly.", flush=True)

# 3. Deploy cgroup sampler directly on VM
print("[+] Uploading and starting 250-ms cgroup sampler directly on VM...", flush=True)
with open("scratch/cgroup_sampler.py", "r", encoding="utf-8") as f:
    sampler_code = f.read()

sftp = ssh.open_sftp()
with sftp.open("/home/osu/ddos_detector/cgroup_sampler.py", "w") as f:
    f.write(sampler_code)
sftp.close()

pod_ips_json = json.dumps(pod_ips)
run_vm("rm -f /tmp/cgroup_sampler.stop /tmp/cpu_memory_samples.jsonl /tmp/cgroup_sampler.log")

start_sampler_cmd = f"python3 /home/osu/ddos_detector/cgroup_sampler.py '{pod_ips_json}' /tmp/cpu_memory_samples.jsonl /tmp/cgroup_sampler.stop 0.25 < /dev/null > /tmp/cgroup_sampler.log 2>&1 &"
run_vm(start_sampler_cmd)
time.sleep(1)

# Verify sampler is running
sampler_ps = run_vm("pgrep -f cgroup_sampler.py")
print(f"[+] Cgroup sampler is running on VM (PID: {sampler_ps}).", flush=True)

# 4. Execute Synchronized 160-RPS Benchmark Trial
TRIAL_ID = "proc_parallel_pilot_3"
RAW_DIR = "scratch/pilot_raw"
os.makedirs(RAW_DIR, exist_ok=True)

print(f"\n[+] Executing Synchronized 160-RPS Four-Service Concurrent Attack: '{TRIAL_ID}'...", flush=True)
trial_result = h.execute_concurrent_trial(TRIAL_ID, RAW_DIR)

# 5. Stop Sampler
print("\n[+] Stopping cgroup sampler...", flush=True)
run_vm("touch /tmp/cgroup_sampler.stop")
time.sleep(1)

# Download samples from VM
sftp = ssh.open_sftp()
sftp.get("/tmp/cpu_memory_samples.jsonl", "scratch/cpu_memory_samples.jsonl")
sftp.close()

sample_lines = run_vm("wc -l /tmp/cpu_memory_samples.jsonl")
print(f"[+] Downloaded scratch/cpu_memory_samples.jsonl ({sample_lines})", flush=True)

# 6. Fetch all detection cycles and inference events recorded during the trial
print("[+] Fetching all detection cycles and inference events across all 4 defenders...", flush=True)
all_attack_cycles = {}
all_cycles_jsonl = []
all_inferences = {}

for svc, ip in pod_ips.items():
    raw_res = run_vm(f"curl -s 'http://{ip}:8080/api/detection_cycles?limit=1000'")
    try:
        data = json.loads(raw_res)
        cycs = data.get("cycles", [])
        all_attack_cycles[svc] = {
            "service": svc,
            "ip": ip,
            "total_cycles": len(cycs),
            "cycles": cycs
        }
        for c in cycs:
            all_cycles_jsonl.append(c)
        print(f"  {svc:<12}: {len(cycs)} cycles recorded during trial", flush=True)
    except Exception as e:
        print(f"  {svc:<12}: Failed to parse cycles ({e})", flush=True)

    # Fetch dedicated inference events
    raw_inf = run_vm(f"curl -s 'http://{ip}:8080/api/inference_events?limit=1000'")
    try:
        data_inf = json.loads(raw_inf)
        infs = data_inf.get("inferences", [])
        all_inferences[svc] = {
            "service": svc,
            "ip": ip,
            "total_inferences": len(infs),
            "inferences": infs
        }
        print(f"  {svc:<12}: {len(infs)} dedicated inference operations recorded", flush=True)
    except Exception as e:
        print(f"  {svc:<12}: Failed to parse inference events ({e})", flush=True)

with open("scratch/detection_cycles_attack.json", "w") as f:
    json.dump(all_attack_cycles, f, indent=2)

with open("scratch/detection_cycles_attack.jsonl", "w") as f:
    for c in sorted(all_cycles_jsonl, key=lambda x: x.get("cycle_start_time", 0)):
        f.write(json.dumps(c) + "\n")

with open("scratch/inference_events_attack.json", "w") as f:
    json.dump(all_inferences, f, indent=2)

print(f"[+] Saved cycles to scratch/detection_cycles_attack.json and inferences to scratch/inference_events_attack.json.", flush=True)

# 7. Post-flight verification
print("\n[+] Verifying post-trial cluster baseline restoration...", flush=True)
vs = h.poll_all_virtual_services()
for k, v in vs.items():
    print(f"  VS {k:<10}: rules={v['rules_count']}, quarantine={v['quarantine_present']}, routes={v['production_routes']}", flush=True)

post_pre = h.run_global_preflight()
held_leases = [k for k, v in post_pre['leases'].items() if v]
print(f"  Held Leases: {held_leases}", flush=True)
defenders_summary = [f"{k}: restarts={v['restarts']}" for k, v in post_pre['defenders'].items()]
print(f"  Defenders: {defenders_summary}", flush=True)

ssh.close()
print("\n[+] PILOT TRIAL COMPLETE AND EVIDENCE PRESERVED SUCCESSFULLY!", flush=True)

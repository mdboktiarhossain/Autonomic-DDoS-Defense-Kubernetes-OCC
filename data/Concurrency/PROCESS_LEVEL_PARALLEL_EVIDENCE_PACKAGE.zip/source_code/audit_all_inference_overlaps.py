import json

data = json.load(open('scratch/inference_events_attack.json'))
all_inf = []
for s, v in data.items():
    for inf in v.get('inferences', []):
        all_inf.append(inf)
all_inf.sort(key=lambda x: x['t_start'])
print(f"Total dedicated inference operations: {len(all_inf)}")
overlaps = 0
for i in range(len(all_inf)):
    inf1 = all_inf[i]
    for j in range(i+1, len(all_inf)):
        inf2 = all_inf[j]
        if inf2['t_start'] < inf1['t_end'] and inf1['service'] != inf2['service']:
            overlaps += 1
            overlap_ms = (min(inf1['t_end'], inf2['t_end']) - max(inf1['t_start'], inf2['t_start'])) * 1000.0
            print(f"  OVERLAP #{overlaps}: {inf1['service']} ({inf1['exec_id']}) & {inf2['service']} ({inf2['exec_id']}) -> {overlap_ms:.2f} ms")

print(f"Total verified concurrent ML inference overlaps: {overlaps}")
